# MyLife V60 — références officielles

Deux références visuelles officielles sont incluses dans `client/reference/` :

1. `mylife-reference-01-official.png` — identité visuelle principale, accueil, profils, publications, Live, boutique, Premium et style général.
2. `mylife-reference-02-official.png` — inscription, connexion, récupération du mot de passe, profil, paramètres et parcours de publication depuis la galerie.

Ces deux fichiers sont les seules références visuelles officielles de V60. Leur SHA-256 est enregistré dans `client/reference/design-reference.json` et vérifié par `npm run verify:reference`.
