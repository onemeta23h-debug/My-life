import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
const checks=[
 ['reference',fs.existsSync('client/reference/mylife-reference-01-official.png')],
 ['design-reference',fs.existsSync('client/reference/design-reference.json')],
 ['livekit-env',fs.readFileSync('.env.example','utf8').includes('LIVEKIT_API_SECRET')],
 ['livekit-server-token',fs.readFileSync('server/index.js','utf8').includes("/api/calls/:id/token")&&fs.readFileSync('server/index.js','utf8').includes("/api/live/:id/token")],
 ['verification-api',fs.readFileSync('server/index.js','utf8').includes("/api/verification/request")&&fs.readFileSync('server/index.js','utf8').includes("/api/admin/verifications")],
 ['verification-worker',fs.existsSync('verification-worker/app.py')],
 ['health',fs.readFileSync('server/index.js','utf8').includes("/api/health")],
];
for(const [n,ok] of checks) console.log(`${ok?'PASS':'FAIL'} ${n}`);
if(checks.some(([,ok])=>!ok))process.exit(1);
execFileSync(process.execPath,['--check','server/index.js'],{stdio:'inherit'});
execFileSync(process.execPath,['--check','client/src/main.js'],{stdio:'inherit'});
