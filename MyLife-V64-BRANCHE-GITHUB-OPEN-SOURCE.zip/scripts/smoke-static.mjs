import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
const root=process.cwd();
const must=[
 'server/index.js','client/index.html','client/src/main.js','.env.example',
 'client/reference/mylife-reference-01-official.png','client/reference/mylife-reference-02-official.png',
 'client/reference/design-reference.json','infra/docker-compose.realtime.yml',
 'infra/livekit/livekit.yaml.example','infra/coturn/turnserver.conf.example'
];
for (const f of must) if(!fs.existsSync(f)) throw new Error(`Missing: ${f}`);
for (const f of ['server/index.js','client/src/main.js']) execFileSync(process.execPath,['--check',f],{stdio:'inherit'});
const server=fs.readFileSync('server/index.js','utf8');
const client=fs.readFileSync('client/src/main.js','utf8');
const env=fs.readFileSync('.env.example','utf8');
const endpoints=[
 '/api/auth/signup','/api/auth/login','/api/discover','/api/posts','/api/messages/',
 '/api/premium/request','/api/admin/premium/','/api/verification/request',
 '/api/admin/verifications/','/api/calls','/api/live','/api/admin/notify',
 '/api/admin/reports/','/api/admin/support/'
];
for(const e of endpoints) if(!server.includes(e)) throw new Error(`Endpoint contract missing: ${e}`);
for(const k of ['JWT_SECRET','ADMIN_EMAIL','ADMIN_PASSWORD','PAYDUNYA_PAYMENT_URL','SUPPORT_EMAIL','SUPPORT_WHATSAPP','LIVEKIT_URL','LIVEKIT_API_KEY','LIVEKIT_API_SECRET','TURN_URL','TURN_USERNAME','TURN_PASSWORD']) if(!new RegExp(`^${k}=`, 'm').test(env)) throw new Error(`ENV contract missing: ${k}`);
for(const s of ['Premium activé','avatar_verified','verification','live','call','support','notifications']) if(!server.toLowerCase().includes(s.toLowerCase())) throw new Error(`Server feature marker missing: ${s}`);
if(!client.includes('Créer une publication') || !client.includes('Administration MyLife')) throw new Error('Client feature contract incomplete');
console.log('MyLife V62 static smoke verification: PASS');
console.log(`Checked ${must.length} required files, ${endpoints.length} endpoint contracts, syntax and environment contract.`);
