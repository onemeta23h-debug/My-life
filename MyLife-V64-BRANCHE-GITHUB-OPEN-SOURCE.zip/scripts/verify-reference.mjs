import fs from 'node:fs';
import crypto from 'node:crypto';
const root=process.cwd();
const files=['client/reference/mylife-reference-01-official.png','client/reference/mylife-reference-02-official.png','client/reference/design-reference.json','REFERENCE.md'];
for(const f of files){if(!fs.existsSync(f))throw new Error(`Missing required official reference file: ${f}`)}
const spec=JSON.parse(fs.readFileSync('client/reference/design-reference.json','utf8'));
for(const [f,expected] of Object.entries(spec.sha256||{})){const got=crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');if(got!==expected)throw new Error(`Reference hash mismatch: ${f}`)}
console.log('MyLife V62 official references OK');
