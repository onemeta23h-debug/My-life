import fs from 'fs';
import path from 'path';
import { spawnSync } from 'child_process';
const root=path.resolve(new URL('..',import.meta.url).pathname);
const required=[
 'server/index.js','client/index.html','client/src/main.js',
 'client/reference/mylife-reference-01-official.png','client/reference/design-reference.json',
 '.env.example','V31-V40-ROADMAP.md','CONFIGURATION-V50.md','SECURITY.md'
];
const missing=required.filter(f=>!fs.existsSync(path.join(root,f)));
if(missing.length){console.error('Fichiers manquants:',missing);process.exit(1)}
for(const f of ['server/index.js','client/src/main.js']){
 const r=spawnSync(process.execPath,['--check',path.join(root,f)],{encoding:'utf8'});
 if(r.status!==0){console.error(r.stderr||r.stdout);process.exit(r.status||1)}
}
const env=fs.readFileSync(path.join(root,'.env.example'),'utf8');
for(const key of ['ADMIN_EMAIL','ADMIN_PASSWORD','PAYDUNYA_PAYMENT_URL','SUPPORT_EMAIL','SUPPORT_WHATSAPP','LIVEKIT_URL','LIVEKIT_API_KEY','LIVEKIT_API_SECRET']){
 if(!new RegExp('^'+key+'=', 'm').test(env)){console.error('Variable .env manquante:',key);process.exit(1)}
}
const ref=fs.statSync(path.join(root,'client/reference/mylife-reference-01-official.png'));
if(ref.size<1000){console.error('Référence visuelle invalide');process.exit(1)}
console.log('V40 verification: OK');
console.log('- reference: OK');
console.log('- client/server syntax: OK');
console.log('- env contract: OK');
console.log('- V31-V40 roadmap/docs: OK');
