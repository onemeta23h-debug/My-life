import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
const root=new URL('..',import.meta.url).pathname;
const required=['.env.example','server/index.js','client/index.html','client/src/main.js','client/reference/mylife-reference-01-official.png','infra/livekit/livekit.yaml.example','infra/coturn/turnserver.conf.example','infra/docker-compose.realtime.yml'];
for(const p of required){if(!fs.existsSync(root+p)) throw new Error('Fichier manquant: '+p)}
for(const f of ['server/index.js','client/src/main.js']) execFileSync(process.execPath,['--check',root+f],{stdio:'inherit'});
const env=fs.readFileSync(root+'.env.example','utf8');
for(const k of ['ADMIN_EMAIL','ADMIN_PASSWORD','PAYDUNYA_PAYMENT_URL','SUPPORT_EMAIL','SUPPORT_WHATSAPP','LIVEKIT_URL','LIVEKIT_API_KEY','LIVEKIT_API_SECRET','TURN_URL','TURN_USERNAME','TURN_PASSWORD']) if(!env.includes(k+'=')) throw new Error('ENV manquant: '+k);
console.log('V50 static verification: OK');
