# MyLife V54 — nouvelles fonctionnalités

## 5 fonctionnalités Premium
1. **Boutique vendeur** : création et publication de produits/services avec prix XOF, stock, catégorie, image et lien HTTPS de contact/achat.
2. **Statistiques avancées du profil** : vues, abonnés, abonnements et likes reçus.
3. **Statistiques vendeur** : produits, vues et favoris de la boutique.
4. **Visibilité prioritaire** : boost Premium de 60 minutes via le serveur.
5. **Accusés de lecture** : statut « Lu » pour les messages Premium.

## 2 fonctionnalités gratuites
1. **Suivre un profil** : suivre/ne plus suivre et consulter abonnés/abonnements.
2. **Favoris boutique** : les utilisateurs gratuits peuvent enregistrer les produits qui les intéressent.

## Sécurité
- Les créations vendeur nécessitent Premium côté serveur.
- Les liens de contact/achat doivent être en HTTPS.
- Les données boutique sont stockées dans SQLite côté serveur.
- Les permissions Premium sont vérifiées côté serveur et non uniquement dans l'interface.
