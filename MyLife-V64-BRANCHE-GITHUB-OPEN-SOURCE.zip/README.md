# MyLife V64

Version de travail full-stack de MyLife, avec interface web/mobile-first, backend Express + SQLite, authentification email/mot de passe, publications, stories, matchs, messagerie, appels WebRTC, Live, boutique, Premium et administration.

## Références officielles

Les **deux images fournies par Trehza Mendoza** sont intégrées à l’identique :

- `client/reference/mylife-reference-01-official.png` — référence principale de l’identité visuelle et des écrans.
- `client/reference/mylife-reference-02-official.png` — référence du parcours de publication depuis la galerie.

Le contrat visuel est décrit dans `client/reference/design-reference.json` et vérifié par SHA-256.

## UI V64

Toutes les pages utilisent le même langage visuel :
- fond noir/violet avec accents néon violet/magenta ;
- panneaux glass/translucides ;
- grands arrondis et espacements réguliers ;
- boutons principaux violet/magenta ;
- badge bleu de vérification ;
- navigation basse à 5 entrées ;
- publication en 5 étapes : sélection, aperçu/édition, description, envoi, résultat.

## Premium

Prix : **10 000 XOF / mois**.

Le paiement est ouvert par le lien `PAYDUNYA_PAYMENT_URL`. La demande est ensuite enregistrée et **l’administration décide de l’activation**. L’activation Premium est contrôlée côté serveur.

## Administration

L’administration utilise le même écran de connexion avec `ADMIN_EMAIL` et `ADMIN_PASSWORD`. Elle peut notamment :
- activer/refuser Premium ;
- activer/refuser une vérification ;
- gérer les utilisateurs ;
- traiter les signalements ;
- répondre au support ;
- envoyer des notifications ;
- consulter le journal d’administration.

## Configuration

1. Copier `.env.example` vers `.env`.
2. Renseigner au minimum `JWT_SECRET`, `ADMIN_EMAIL` et `ADMIN_PASSWORD`.
3. Ajouter le lien PayDunya et les coordonnées de support si disponibles.
4. Pour les appels/Live en production, configurer HTTPS et, selon le réseau, TURN/SFU/LiveKit.
5. Installer les dépendances avec `npm install`.
6. Lancer avec `npm start`.

## Vérifications statiques

```bash
npm run verify:reference
npm run verify:v40
npm run verify:v50
```

Les tests ci-dessus vérifient les références officielles, la syntaxe JS et le contrat de configuration. Le fonctionnement réel des appels/Live dépend des services réseau effectivement configurés au déploiement.

Powered by **Trehza Mendoza**.


## V63
Voir `V63-BRANCHEMENTS.md` pour les fonctions branchées et les services qui nécessitent encore des identifiants externes. Les deux références officielles dans `client/reference/` ne doivent pas être remplacées.


## V64 — branchements open source
- Notifications Web Push intégrées avec `web-push` et génération locale des clés VAPID au premier démarrage.
- Service worker `client/sw.js` pour recevoir les notifications.
- Appels audio/vidéo et Live utilisent LiveKit automatiquement lorsque `LIVEKIT_URL`, `LIVEKIT_API_KEY` et `LIVEKIT_API_SECRET` sont configurés; sinon le WebRTC direct existant reste utilisé.
- TURN/coturn reste compatible via `TURN_URL`, `TURN_USERNAME`, `TURN_PASSWORD`.
- Les références officielles MyLife restent inchangées.
- Aucun secret ou identifiant inventé.
