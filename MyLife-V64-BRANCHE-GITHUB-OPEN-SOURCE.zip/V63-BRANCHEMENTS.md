# MyLife V63 — branchements réels

## Branché dans le code
- Récupération de mot de passe avec token à usage unique, expiration 30 min et envoi SMTP configurable.
- Suspension / réactivation d'un utilisateur par l'administration.
- Suppression d'un compte utilisateur par l'administration (les comptes admin sont protégés).
- Journalisation des actions d'administration ci-dessus.
- Blocage serveur d'un compte suspendu.
- `.env.example` complété pour SMTP.
- Premium toujours activé uniquement par l'administration.
- Les deux références officielles restent inchangées et sont vérifiées par `npm run verify:reference`.

## À renseigner par toi dans `.env`
- `JWT_SECRET`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `PUBLIC_APP_URL`
- `PAYDUNYA_PAYMENT_URL`
- `SUPPORT_EMAIL` / `SUPPORT_WHATSAPP`
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`
- `TURN_URL`, `TURN_USERNAME`, `TURN_PASSWORD`
- `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`
- `VERIFICATION_WORKER_URL`
- réseaux sociaux officiels

## Encore dépendant d'un service externe
- SMTP : nécessite un vrai fournisseur et ses identifiants.
- TURN : nécessite un serveur TURN.
- LiveKit : nécessite un serveur LiveKit et ses identifiants.
- Worker de vérification : nécessite le déploiement du worker.
- Notifications push natives iOS/Android : pas incluses tant que APNs/FCM ne sont pas configurés.

## Vérifications effectuées
- Syntaxe serveur/client : PASS
- Références officielles : PASS
- Smoke statique : PASS
- Installation complète des dépendances npm : non terminée dans l'environnement de build (timeout réseau).
