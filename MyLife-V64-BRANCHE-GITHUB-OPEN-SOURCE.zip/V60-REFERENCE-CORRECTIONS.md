# MyLife V60 — correction des références et du parcours UI

- Les deux images fournies par Trehza Mendoza sont intégrées **à l’identique** comme références officielles.
- Aucun ancien fichier `lova-up` ou ancienne référence MyLife n’est conservé dans `client/reference/`.
- Toutes les pages utilisent le même système visuel : fond noir/violet, surfaces glass, arrondis, actions violettes, badge bleu, navigation basse.
- Le parcours de publication reprend les 5 étapes de la seconde référence : sélection, édition/aperçu, description, envoi, résultat.
- Premium reste activé uniquement côté administration après vérification du paiement.
- Les appels/Live restent dépendants de HTTPS et de TURN/SFU/LiveKit correctement configurés pour les réseaux réels.
