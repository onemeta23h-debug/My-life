# MyLife V60 — référence, identité et UX

- Nom : MyLife
- Signature : powered by Trehza Mendoza
- Référence principale : `client/reference/mylife-reference-01-official.png`
- Référence Premium : `client/reference/mylife-reference-01-official.png` et `.svg`
- Logo : `client/logo.svg`, cœur + couple
- Icônes de création de compte : `client/icons/`
- Style : sombre/violet, grands médias arrondis, panneau translucide, contrôles circulaires, navigation basse mobile.
- Inscription : nom, identifiant unique, âge 18+, pays, ville, recherche et photo réelle obligatoire; téléphone, travail et animal restent facultatifs.
- Paramètres : langue, confidentialité par champ, incognito, notifications, appels/live, sécurité contenu, blocages/interactions, Premium, données et légal.
- Publication : carte lisible avec auteur, badge bleu, date, texte, média, liens séparés et actions distinctes.
- Vérification : le badge bleu n'est affiché que lorsque la validation serveur est approuvée.

## Protection
Le projet applique les contrôles côté serveur existants pour l'authentification, les permissions Premium, les médias et la vérification. Une protection web ne peut pas garantir l'interdiction des captures d'écran; les protections natives devront être ajoutées pour Android/iOS.
