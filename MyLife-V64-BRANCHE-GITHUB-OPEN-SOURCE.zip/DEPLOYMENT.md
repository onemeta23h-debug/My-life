# Déploiement V53

## Serveur Node recommandé
V53 regroupe frontend + API + WebSocket dans un même processus. Utiliser un hébergement qui accepte un processus Node long-lived et les WebSockets.

### Variables minimales
- `JWT_SECRET`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `DJUMYA_PAYMENT_URL`
- `SUPPORT_EMAIL`

### Commandes
```bash
npm install
npm start
```

Le port est `PORT` (3000 par défaut).

## Important pour la production
- Utiliser une longue valeur aléatoire pour `JWT_SECRET`.
- Ne pas committer `.env`.
- Remplacer SQLite par PostgreSQL et le dossier `uploads/` par un stockage objet avant une montée en charge importante.
- Les appels WebRTC utilisent STUN et la signalisation V53. Ajouter un serveur TURN pour les réseaux restrictifs.
- Le Live fourni utilise une topologie WebRTC maillée pour de petites salles; un SFU est recommandé pour de grandes audiences.
- Google Login reste désactivé tant que les vraies credentials OAuth ne sont pas fournies.


### Configuration minimale
Remplir dans `.env` : `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `PAYDUNYA_PAYMENT_URL`, `SUPPORT_EMAIL`, `SUPPORT_WHATSAPP`, `JWT_SECRET`. Les services Google/LiveKit/TURN restent optionnels tant que leurs credentials ne sont pas disponibles.
