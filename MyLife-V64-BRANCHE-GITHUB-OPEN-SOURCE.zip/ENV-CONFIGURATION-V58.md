# MyLife V60 — Configuration .env

Les valeurs privées restent dans `.env` et ne doivent jamais être publiées dans le dépôt.

## Administration
- `ADMIN_EMAIL` : adresse utilisée pour le compte administrateur initial.
- `ADMIN_PASSWORD` : mot de passe initial. Le serveur le transforme en hash bcrypt lors de la création du compte.

## Premium / paiement
- `PREMIUM_PRICE_XOF=10000`
- `PREMIUM_DURATION_DAYS=30`
- `PAYDUNYA_PAYMENT_URL` : lien de paiement Premium PayDunya.

## Support
- `SUPPORT_EMAIL`
- `SUPPORT_WHATSAPP`
- `SUPPORT_WHATSAPP_MESSAGE`

## Réseaux officiels
- `MYLIFE_TIKTOK_URL`
- `MYLIFE_INSTAGRAM_URL`

## Important
Google Login a été supprimé de V60 : aucune variable OAuth Google n'est nécessaire.
Ne place jamais un mot de passe administrateur, JWT secret, clé LiveKit ou identifiant TURN dans le frontend.
