# MyLife V50 — appels et Live

V50 utilise LiveKit comme SFU pour les appels audio/vidéo et le Live, avec coturn pour le relais TURN.

Sources open source utilisées comme références :
- LiveKit server: https://github.com/livekit/livekit (Apache-2.0)
- coturn: https://github.com/coturn/coturn (BSD)

Important : GitHub ne fournit pas les credentials privés de ton application. `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`, l'URL publique et les credentials TURN doivent être créés/configurés par le propriétaire du serveur.
