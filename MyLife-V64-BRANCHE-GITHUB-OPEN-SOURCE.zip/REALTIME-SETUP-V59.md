# MyLife V60 — temps réel

Le projet contient maintenant :
- WebSocket de signalisation pour appels et événements Live.
- WebRTC navigateur pour appels audio/vidéo.
- Configuration TURN via `TURN_URL`, `TURN_USERNAME`, `TURN_PASSWORD`.
- Endpoints LiveKit pour une infrastructure LiveKit/SFU lorsqu'elle est configurée.
- Live utilisateur avec caméra/micro et gestion de session côté serveur.

Important : un appel/Live réellement utilisable sur Internet dépend de l'infrastructure réseau. Pour une production robuste, renseigner un serveur TURN et, pour un Live à grande échelle, LiveKit. Les identifiants privés restent dans `.env` et ne doivent jamais être commités.
