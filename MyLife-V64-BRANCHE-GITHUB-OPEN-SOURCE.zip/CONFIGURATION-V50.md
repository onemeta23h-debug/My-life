# Configuration V52

## Champs indispensables pour ton premier déploiement

```env
ADMIN_EMAIL=
ADMIN_PASSWORD=
PAYDUNYA_PAYMENT_URL=
SUPPORT_EMAIL=
SUPPORT_WHATSAPP=
JWT_SECRET=
```

## Appels et Live

```env
LIVEKIT_URL=
LIVEKIT_API_KEY=
LIVEKIT_API_SECRET=
TURN_URL=
TURN_USERNAME=
TURN_PASSWORD=
```

Tu peux laisser ces champs vides au début. L'application affiche l'état de configuration et ne prétend pas qu'un service externe est actif lorsqu'il ne l'est pas.

## Google

```env
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
```

Google Login reste optionnel tant que les credentials OAuth ne sont pas créées.

## Sécurité

- Ne mets jamais `.env` dans GitHub.
- `ADMIN_PASSWORD` sert uniquement à initialiser le compte admin ; le mot de passe est haché avant stockage.
- `JWT_SECRET` doit être une valeur aléatoire longue en production.
- Les clés LiveKit restent côté serveur.

## V52 additions
- Stories 24 h (photo free; video Premium).
- Invitations d'amis, acceptation/refus et liste d'amis.
- 5 outils Premium: visites de profil, boost, filtres avancés, mode voyage, annulation du dernier swipe (UI prête; l'historique complet des swipes reste à brancher).
- Récompense quotidienne gratuite.
- Protection d'interface contre sélection/copie/glisser-déposer et menu contextuel sur contenus personnels. Cette protection ne peut pas garantir l'absence de captures d'écran sur un navigateur; un contrôle natif est nécessaire pour un blocage OS complet.
- UI renforcée: boutons solides, grille cohérente, éléments alignés et référence visuelle MyLife conservée.

- Paramètres de compte: langue et confidentialité enregistrées côté serveur.
- 4 nouveaux outils Premium: likes reçus, Super Likes illimités, compatibilité avancée, mode incognito.
- 1 Super Like gratuit par jour pour les comptes gratuits.
