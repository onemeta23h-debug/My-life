# MyLife V31 → V40

V30 reste la base fonctionnelle. V31–V40 constituent une série d'améliorations livrées dans la V40 finale afin d'éviter de casser les fonctions déjà branchées.

## V31 — Comptes et sécurité
- validation 18+
- mots de passe hachés
- JWT serveur
- rôles utilisateur/admin
- vérification de configuration

## V32 — Profils et découverte
- profils persistants
- filtres
- likes/matchs
- statut en ligne/dernière activité

## V33 — Publications
- photos
- vidéos Premium
- commentaires
- likes
- liens externes
- notifications de publication

## V34 — Messagerie
- historique persistant
- WebSocket
- notification nouveau message
- événements temps réel

## V35 — Notifications
- création de compte
- publications
- likes/commentaires
- messages
- Premium
- support
- notifications admin
- liens admin rendus sous forme de boutons

## V36 — Premium
- 10 000 XOF / 30 jours par défaut
- paiement via lien PayDunya
- activation/refus manuel par admin
- expiration automatique du Premium
- activation directe par l'administration

## V37 — Support
- bouton casque 🎧
- tickets support
- réponses admin
- email
- WhatsApp avec message prérempli

## V38 — Appels
- signalisation WebSocket
- audio/vidéo
- intégration LiveKit lorsque les credentials sont présentes
- fallback WebRTC

## V39 — Live
- création/participation
- caméra/micro
- LiveKit SFU lorsque configuré
- fallback WebRTC petite salle

## V40 — Consolidation
- configuration .env centralisée
- diagnostic `/api/health`
- vérifications syntaxiques
- référence visuelle embarquée
- documentation de déploiement
- conservation de la compatibilité V30

## Ce qui reste dépendant de services externes
Google Login, LiveKit/TURN et le lien PayDunya ne peuvent pas recevoir de vraies credentials inventées. Ils deviennent actifs dès que leurs variables sont renseignées.
