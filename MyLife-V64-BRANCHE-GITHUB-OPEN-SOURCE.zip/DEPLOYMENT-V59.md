# Déploiement MyLife V60

## 1. Configuration
Copier `.env.example` vers `.env` puis renseigner uniquement les valeurs que vous possédez.

Champs importants :
- `ADMIN_EMAIL` / `ADMIN_PASSWORD`
- `PAYDUNYA_PAYMENT_URL`
- `SUPPORT_EMAIL` / `SUPPORT_WHATSAPP`
- `MYLIFE_TIKTOK_URL` / `MYLIFE_INSTAGRAM_URL`
- `JWT_SECRET`
- `TURN_URL` / `TURN_USERNAME` / `TURN_PASSWORD` pour les réseaux nécessitant un relais WebRTC
- `LIVEKIT_URL` / `LIVEKIT_API_KEY` / `LIVEKIT_API_SECRET` pour un Live/SFU à grande échelle

## 2. Authentification
Google Login est supprimé. L'authentification utilise e-mail + mot de passe.

## 3. Temps réel
Les appels audio/vidéo utilisent WebRTC et le serveur WebSocket pour la signalisation. Le Live utilise WebRTC pour le direct et peut être migré vers LiveKit via les endpoints et variables déjà présents.

## 4. Références
Les deux références officielles sont dans `client/reference/` et sont incluses dans l'archive.

## 5. Sécurité
Ne jamais mettre les secrets réels dans le dépôt Git ou dans le frontend. Utiliser HTTPS en production.
