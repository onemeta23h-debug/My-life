import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from deepface import DeepFace

app=FastAPI(title="LOVA-UP Verification Worker")
class Req(BaseModel):
    verificationId:int
    documentPath:str
    selfiePath:str

@app.get("/health")
def health(): return {"ok":True}

@app.post("/verify")
def verify(x:Req):
    try:
        live=DeepFace.extract_faces(img_path=x.selfiePath,anti_spoofing=True,detector_backend="opencv")
        real=all(bool(f.get("is_real")) for f in live) and len(live)==1
        if not real: return {"verificationId":x.verificationId,"liveness_score":0,"similarity_score":0,"decision":"manual_review"}
        result=DeepFace.verify(img1_path=x.documentPath,img2_path=x.selfiePath,model_name=os.getenv("FACE_MODEL","SFace"),detector_backend="opencv",anti_spoofing=True)
        confidence=float(result.get("confidence",0))
        distance=float(result.get("distance",0))
        return {"verificationId":x.verificationId,"liveness_score":100,"similarity_score":confidence,"distance":distance,"decision":"manual_review" if not result.get("verified") else "manual_review"}
    except Exception as e:
        raise HTTPException(422,str(e))
