# Sécurité V53

- 18+ obligatoire pour créer un compte.
- Mots de passe hachés avec bcrypt.
- JWT signé côté serveur.
- Autorisation admin séparée.
- Uploads limités et extensions filtrées.
- Les secrets ne sont jamais embarqués dans le frontend.
- Les demandes de vérification d'identité restent côté serveur.
- Le badge « Vérifié MyLife » ne doit être accordé qu'après validation de la procédure de vérification prévue.
- Pour une production à grande échelle, remplacer SQLite par PostgreSQL et utiliser un stockage objet pour les médias.
