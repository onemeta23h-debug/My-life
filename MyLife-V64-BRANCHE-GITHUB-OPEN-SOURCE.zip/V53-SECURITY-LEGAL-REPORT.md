# MyLife V53 — sécurité, confidentialité et fonctions réelles

- Nom produit : MyLife
- Signature : powered by Trehza Mendoza
- Âge minimum : 18 ans
- Photo de profil réelle obligatoire à l'inscription
- Identifiant public unique
- Consentement Conditions + Confidentialité enregistré
- Pays, ville, recherche, animal, travail et téléphone séparés
- Téléphone non public par défaut
- Travail masqué par défaut
- Réglages de visibilité par champ
- Export des données
- Demande de suppression de compte
- Médias servis derrière authentification
- Contrôle MIME + extension pour les uploads
- Appels audio/vidéo et Live avec signalisation réelle
- Double appui sur photo/publication pour aimer
- Administration protégée par rôle
- Journal d'audit des actions administratives sensibles
- Vérification identité avec consentement, selfie et document, puis revue admin
- Les secrets restent côté serveur via .env

La conformité juridique finale dépend du pays de déploiement, des textes juridiques publiés et des obligations locales applicables ; ce projet fournit une base technique de conformité, pas un avis juridique.
