# MyLife verification pipeline

V30 uses a server-side verification workflow: identity document + live selfie, anti-spoofing signal, face similarity, then manual admin decision. The project does **not** automatically grant the verified badge from an unverified model result.

Recommended open-source components researched: OpenCV Zoo YuNet/SFace and MiniVision Silent-Face-Anti-Spoofing. OpenCV Zoo states its SFace model directory is Apache-2.0, but a 2026 issue asks for clarification about commercial-use/training-data provenance for the exact ONNX weights; therefore the weights are not silently bundled. DeepFace is MIT but wraps models with their own licenses.

Before production, configure the model worker and retain the corresponding licenses/notices.
