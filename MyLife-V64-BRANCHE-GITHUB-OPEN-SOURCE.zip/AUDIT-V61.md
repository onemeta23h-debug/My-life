# MyLife V61 — audit fonctionnel

Date: 2026-10-02

## Corrections effectuées
- Connexion: accepte maintenant l'e-mail **ou l'identifiant unique @username**, conformément à l'interface.
- Médias privés: les fichiers `/media/*` restent protégés par authentification; les balises image/vidéo du navigateur utilisent un jeton d'accès court lié au JWT de session via `?access=`.
- Titre HTML mis à jour vers MyLife V61.
- Images du profil, publications, stories et Live utilisent le helper de média protégé.

## Vérifications réalisées
- `node --check server/index.js` : OK
- `node --check client/src/main.js` : OK
- `node scripts/verify-reference.mjs` : OK
- Les deux références officielles sont présentes et leurs SHA-256 correspondent au contrat `design-reference.json`.

## Tests non réalisés dans cet environnement
L'installation des dépendances npm a dépassé le délai disponible; `node_modules` n'était donc pas disponible pour lancer le serveur et effectuer un test HTTP/SQLite complet. Les appels audio/vidéo et LiveKit nécessitent aussi les valeurs réelles de `.env` (TURN/LiveKit) pour un test réseau réel.

## Points à configurer avant production
- `JWT_SECRET`
- compte administrateur
- PayDunya
- SMTP/support e-mail si utilisé
- TURN
- LiveKit
- stockage/serveur de production
